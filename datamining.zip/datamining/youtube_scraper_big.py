from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd
import time

# ChromeDriver otomatik olarak ayarlanır
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))

video_urls = [
    "https://youtu.be/hg3umXU_qWc?si=-VJm29X7nAQfmFFQ",
    "https://youtu.be/1mVuM6OeT7w?si=PCvCPE2fXaGwwyHW",
    "https://youtu.be/91ZWRf3GA6k?si=oDy7PJLxY3kolazr",
    "https://youtu.be/3WMuzhQXJoY?si=fNnRb79aeMBS9_ek",
    "https://youtu.be/pLCiAXluZsY?si=QOuGTSwiMe53sUdT",
    "https://youtu.be/H50eCfpquBI?si=CZGpuDYhsCo3WT1e",
    "https://youtu.be/fXk7I_KUj4Q?si=HZNeXk9SmrJn1s-J",
    "https://youtu.be/-asbl0IsvvU?si=30GbzN-b7dkQ-bsG",
    "https://youtu.be/dOV6Y_nzEZY?si=tFr_wG23velQ2bWQ",
    "https://youtu.be/k5icfdBUZT0?si=ylI4cNnGALDiiLPV",
    "https://youtu.be/hE_QvMfV2cs?si=A0d-XT6lkQ9Kv4im",
    "https://youtu.be/YmXdIlN-6qM?si=EPLrl5ZH-p6xTGo3",
    "https://youtu.be/ew7hMibdd84?si=RfUPRkUqdKRbrTSW",
    "https://youtu.be/AKDi9Kcy-T0?si=H4epmrJbAXqvuyUe",
    "https://youtu.be/cYpELqKZ02Q?si=8yZg41Z60RylKMrW",
    "https://youtu.be/9GDjT3Fw_6w?si=jxl8LqAmUC793cnS",
    "https://youtu.be/BucgQh_qkRM?si=Bmb8kB9QwMPLHxyr",
    "https://youtu.be/bVH_c-s9Oho?si=dJZ0dtm_zZaM7hAq",
    "https://youtu.be/RgUwiiOJNEI?si=HflxpKny7IKc4MbE",
    "https://youtu.be/VWNYeRaCVu8?si=tkF8eFlo8tuJhB_m",
    "https://youtu.be/18uDutylDa4?si=CulEqBKv90TCc8rq",
    "https://youtu.be/q0YFY3QqIHI?si=v-rGk2XvXqBzjWeH",
    "https://youtu.be/ZGdOXCLEzB0?si=qO-MsaFIKBY1EKJs",
    "https://youtu.be/cPaE5Fjlpng?si=ssfYJlhxYV90WIC_",
    "https://youtu.be/Sn96bFiZgDE?si=Km5rp2raV3mIzPlm",
]

all_comments = []

for url in video_urls:
    driver.get(url)
    print(f"Video açılıyor: {url}")
    time.sleep(5)

    last_height = driver.execute_script("return document.documentElement.scrollHeight")
    scroll_count = 0
    max_scrolls = 300

    while scroll_count < max_scrolls:
        driver.find_element(By.TAG_NAME, 'body').send_keys(Keys.END)
        time.sleep(4)
        new_height = driver.execute_script("return document.documentElement.scrollHeight")
        if new_height == last_height:
            print("Daha fazla yorum yüklenmedi.")
            break
        last_height = new_height
        scroll_count += 1
        if scroll_count % 50 == 0:
            print(f"{scroll_count} kere kaydırıldı...")

    comments = driver.find_elements(By.XPATH, '//*[@id="content-text"]')
    video_comments = [comment.text for comment in comments]
    print(f"{len(video_comments)} yorum çekildi: {url}")
    all_comments.extend(video_comments)

df = pd.DataFrame(all_comments, columns=["comment"])
df.to_csv("youtube_comments_multi_big.csv", index=False)

print(f"Tüm videolardan toplam {len(all_comments)} yorum kaydedildi!")
driver.quit()
