import pandas as pd
import re
from nltk.corpus import stopwords

# Veriyi oku
df = pd.read_csv("clean_only.csv")

# İngilizce ve Türkçe stopword listesi
eng_stop = set(stopwords.words('english'))
tur_stop = set([
    've', 'bu', 'da', 'de', 'bir', 'çok', 'ama', 'ben', 'sen', 'biz', 'siz', 'ile',
    'gibi', 'şey', 'mı', 'mi', 'mu', 'mü', 'ki', 'ne', 'için', 'daha', 'en', 'ya',
    'o', 'a', 'e', 'var', 'yok', 'diye', 'her', 'şu', 'hep', 'niye'
])

all_stopwords = eng_stop.union(tur_stop)

# Güvenli stopword temizleme fonksiyonu
def remove_stopwords(text):
    if not isinstance(text, str):  # Metin değilse boş string döndür
        return ""
    words = text.split()
    filtered = [word for word in words if word not in all_stopwords]
    return ' '.join(filtered)

# Boş olanları temizle (isteğe bağlı, güvenli)
df = df.dropna(subset=['clean_comment'])

# Stopword'leri temizle
df['clean_nostop_comment'] = df['clean_comment'].apply(remove_stopwords)

# Sonucu kaydet
df.to_csv("youtube_comments_cleaned_nostop.csv", index=False)

# Örnek göster
print("✅ Stopword temizliği tamamlandı.\n🔍 Örnekler:")
print(df[['clean_comment', 'clean_nostop_comment']].sample(5))
