import pandas as pd

df = pd.read_csv("youtube_comments_labeled.csv")

# Etiket dağılımını gör
print(df['label'].value_counts())

# Pie chart (isteğe bağlı görsel)
import matplotlib.pyplot as plt

df['label'].value_counts().plot.pie(autopct='%1.1f%%', colors=['green', 'gray', 'red'], ylabel='')
plt.title("Yorumların Duygu Etiket Dağılımı")
plt.show()
