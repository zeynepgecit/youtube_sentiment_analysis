import pandas as pd
from textblob import TextBlob

# Veriyi oku
df = pd.read_csv("youtube_comments_cleaned_nostop.csv")

# Duygu skoru hesapla
def get_sentiment(text):
    if not isinstance(text, str) or text.strip() == "":
        return 0.0
    return TextBlob(text).sentiment.polarity

# Polarity hesapla
df['sentiment'] = df['clean_nostop_comment'].apply(get_sentiment)

# Etiketle: pozitif / negatif / nötr
def label_sentiment(score):
    if score > 0.1:
        return 'positive'
    elif score < -0.1:
        return 'negative'
    else:
        return 'neutral'

df['label'] = df['sentiment'].apply(label_sentiment)

# Yeni CSV'ye kaydet
df.to_csv("youtube_comments_labeled.csv", index=False)

# Örnekleri göster
print("✅ Duygu analizi tamamlandı.\n🔍 Örnek etiketli veriler:")
print(df[['clean_nostop_comment', 'sentiment', 'label']].sample(5))
